export enum enRepartoWeb {
    Tutto = 0,
    StampaOffset = 1,
    StampaDigitale = 2,
    Packaging = 3,
    Ricamo = 4,
    Etichette = 5,
    ProdottoFinito = 6,
}