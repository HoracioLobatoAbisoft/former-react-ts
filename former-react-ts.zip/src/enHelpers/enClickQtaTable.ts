import React from 'react'

const enClickQtaTable = () => {
    return {}
}

export default enClickQtaTable