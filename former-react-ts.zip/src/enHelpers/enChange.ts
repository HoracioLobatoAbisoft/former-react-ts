export enum enChangeFormato {
    formato = 1,
    tipodicarta = 2,
    coloridiStampa = 3,
}