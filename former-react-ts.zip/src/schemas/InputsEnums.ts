export enum enAsseXYZ {
    Altezza = 1,
    Base = 2,
    Profondita = 3,
}