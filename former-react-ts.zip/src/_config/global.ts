export const GLOBAL_CONFIG = {
  
  IMG_IP :'https://localhost:44311',
  //IMG_IP :'https://tipografiaformer.it',
  //IMG_IP :'https://tipografiaformertest.it',

  HOST_IP :'https://localhost:7143',
  //HOST_IP :'https://localhost:44377',
  //HOST_IP : 'https://tipografiaformertest.it:5050',
  //HOST_IP : 'https://tipografiaformer.it:60',

  PAYPAL_CLIENT_ID: 'AX6SWUyZ9ds_gVvQJejH_cAQbXppe7Ja8QqkIp-YzZyHdvD9osI7UE38Lrzl_cJj6prOmhLl_Vn_2VRz',
  PAYPAL_API_SECRET: "EOy_t_F7STfLpgr1TEnPfMYlyIzqTo6sLxu1M9vjLpP-iDy3v8v4ewYn2vg71rJidEcvzluxpiNrTqBY",
  PAYPAL_API: "https://api-m.sandbox.paypal.com",

  
};