import { GLOBAL_CONFIG } from '../../../../_config/global';
import AcordionLavori from './AcordionLavori';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import { OrdineList } from '../../Interfaces/OrdiniIntarface';

import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { useState } from 'react';
import { DataGetOrdiniById } from '../../Interfaces/GetOrdiniById';
type PropsAcordionOrdini = {
    listOrdini: OrdineList[]
    pageOrdini: number[];
    handleGetOrdini: (pageNumber: number, idUt?: number) => Promise<void>
    handleRedirectToDetaglioOrdini: Function;
    handleDeleteOrdine: Function;
    handleRedirectToDetaglioLavoro: Function;
    handleNewTagListinoTemplate: Function;
    handleDeleteLavoro: Function;
    handleChange: (panel: string) => (event: React.SyntheticEvent<Element, Event>, isExpanded: boolean) => void;
    expanded: string | false;
    dataOrdini: DataGetOrdiniById | undefined
}




const AcordionOrdini = ({ listOrdini, pageOrdini, handleGetOrdini, handleRedirectToDetaglioOrdini, handleDeleteOrdine, handleRedirectToDetaglioLavoro, handleNewTagListinoTemplate, handleDeleteLavoro,dataOrdini,expanded,handleChange }: PropsAcordionOrdini) => {

    


    return (
        <>

            <div className='w-[790px] p-4'>
                <div className=' w-full bg-white'>
                    <div className='flex flex-row'>
                        <div className='w- full text-[10px]'>
                            <span className=''>
                                Da qui puoi visualizzare lo stato dei tuoi Ordini. Clicca sul <b className='text-[1.2em]'>+</b> che vedi accanto a ogni Ordine per visualizzare il dettaglio dell' le tue consegne.
                            </span>
                        </div>
                    </div>
                    <div className='flex flex-row mt-[15px]'>
                        <div className='ml-[65px] w-[130px] flex justify-center px-1'>
                            <span className='text-[red] text-[10px] font-bold text-center'>
                                STATO
                            </span>
                        </div>
                        <div className='w-[120px] flex justify-center px-1'>
                            <span className='text-[red] text-[10px] font-bold'>
                                CONSEGNA
                            </span>
                        </div>
                        <div className='w-[100px] flex justify-center px-1'>
                            <span className='text-[red] text-[10px] font-bold'>
                                DATA CONSEGNA
                            </span>
                        </div>
                        <div className='w-[160px] flex justify-start px-1'>
                            <span className='text-[red] text-[10px] font-bold text-center'>
                                CORRIERE
                            </span>
                        </div>
                        <div className='w-[70px]  flex justify-start self-end'>
                            <span className='text-[red] text-[10px] font-bold'>
                                N° ORDINE
                            </span>
                        </div>
                        <div className='flex w-[110px] justify-end ml-[10px] px-1 self-end'>
                            <span className='text-[red] text-[10px] font-bold text-right'>
                                IMPORTO NETTO

                            </span>
                        </div>

                    </div>
                </div>
                <div className='w-full bg-white acc-ordini'>
                    {
                        listOrdini.map((item, index) => {
                            return (
                                <Accordion
                                    key={index}
                                    className='py-[1.3px]'
                                    expanded={expanded === `${item.idConsegna}`} onChange={handleChange(`${item.idConsegna}`)}
                                >
                                    <AccordionSummary
                                        //expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        sx={{ bgcolor: '#f1f1f1', border: 1, borderColor: '#aaa', borderRadius: 1, display: 'flex', alignItems: 'center', padding: 0, height: '15px', width: '760px', }}
                                        className={`arcodion-ordini`}
                                    >
                                        <div className='w-full flex flex-row items-center justify-center'>
                                            {expanded === `${item.idConsegna}` ?
                                                <RemoveIcon sx={{ fontSize: 15 }} /> :
                                                <AddIcon sx={{ fontSize: 15 }} />
                                            }
                                            <div className="w-[30px]  items-center justify-center">
                                                <img src={GLOBAL_CONFIG.IMG_IP + "/" + item.iconaCorriere} alt="" />
                                            </div>
                                            <div className='w-[30px]  items-center justify-center'>
                                                <div
                                                    style={{ 'backgroundColor': `${item.coloreStatoHtml}` }}
                                                    className={` w-[25px] h-[25px] rounded border-[1px] border-[#aaa]`}
                                                />
                                            </div>
                                            <div className="w-[80px] text-[11px] leading-[16px]">
                                                {item.statoStr}
                                            </div>
                                            <div className="w-[140px] justify-center">
                                                <span className='text-[11px] font-bold text-center'>
                                                    {`N° ${item.idConsegnaView} del ${item.inseritoStr}`}
                                                </span>
                                            </div>
                                            <div className='w-[90px] flex justify-center'>
                                                <span className={`bg-[${item.dataOrdineClasse}] text-center ${['purple', 'green'].includes(item.dataOrdineClasse) ? 'text-[white]' : ''} rounded text-[11px] p-[1px] px-[2px] font-bold`}>
                                                    {item.giornoStr}
                                                </span>
                                            </div>
                                            <div className='w-[165px] flex justify-start'>
                                                <span className='text-[11px] font-bold'>
                                                    {item.corriereStr}
                                                </span>
                                            </div>
                                            <div className="w-[70px] flex justify-center">
                                                <span className='text-[11px] text-center font-bold'>
                                                    {item.count}
                                                </span>
                                            </div>
                                            <div className='w-[120px] flex justify-end'>
                                                <span className='font-bold text-[12px] text-right'>
                                                    € {item.importoTotNettoStr} + iva
                                                </span>
                                            </div>
                                        </div>

                                    </AccordionSummary>
                                    <AccordionDetails
                                        sx={{ bgcolor: "", display: '', fontSize: 11, width: '760px', border: '1px solid #ddd', }}
                                    >
                                        <div className="flex w-full p-0">
                                            <div className='row m-0 w-full'>
                                                <div className="col m-0 col-9">
                                                    <div className='row'>
                                                        <div className='col col-12'>
                                                            <b>Riepilogo Consegna</b>
                                                        </div>
                                                    </div>
                                                    <div className='row'>
                                                        <div className='col col-4'>
                                                            <p>
                                                                Data Consegna
                                                            </p>
                                                        </div>
                                                        <div className='col col-8'>
                                                            <span className={`bg-[${dataOrdini?.dataOrdineClasse}] ${['purple', 'green'].includes(String(dataOrdini?.dataOrdineClasse)) ? 'text-[white]' : ''} p-1 rounded font-bold`} >
                                                                {dataOrdini?.giornoStr} {dataOrdini?.dataOrdineLabel}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className='row mt-1'>
                                                        <div className='col col-4'>
                                                            <span>
                                                                N° Ordine
                                                            </span>
                                                        </div>
                                                        <div className='col col-8'>
                                                            <span className='m-1 font-bold'>
                                                                {dataOrdini?.count}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className='row mt-[3px]'>
                                                        <div className='col col-4'>
                                                            <span>
                                                                Corriere
                                                            </span>
                                                        </div>
                                                        <div className='col col-8'>
                                                            <div className='row mt-[3px]'>
                                                                <div className='col col-12'>
                                                                    <p className="font-bold"> {dataOrdini?.corriereStr}</p>
                                                                </div>
                                                            </div>
                                                            <div className='row mt-[3px]'>
                                                                <div className='col col-12'>
                                                                    <p className="">(Colli <b>{dataOrdini?.numeroColliStr}</b>, Peso <b>{dataOrdini?.pesoKG}</b> kg ±)</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='row mt-[3px]'>
                                                        <div className='col col-4'>
                                                            <span>
                                                                Indirizzo
                                                            </span>
                                                        </div>
                                                        <div className='col col-8'>
                                                            <p className='font-bold'>
                                                                {dataOrdini?.indirizzoStr}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className='row mt-[3px]'>
                                                        <div className='col col-4'>
                                                            <span>
                                                                Pagamento
                                                            </span>
                                                        </div>
                                                        <div className='col col-8'>
                                                            <p className='font-bold'>
                                                                {dataOrdini?.pagamentoStr}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col col-3">
                                                    <div className='row mt-[20px]'>
                                                        <div className={`col col-12`}>
                                                            <div className='flex  justify-center items-center'>
                                                                <span style={{ background: dataOrdini?.coloreStatoHtml }} className={`p-1 rounded font-bold`}>
                                                                    {dataOrdini?.statoStr}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='row mt-[15px]'>
                                                        <div className='w-full flex justify-between'>
                                                            <span>
                                                                Totale Ordini:
                                                            </span>
                                                            <span className='text-end font-bold'>
                                                                € {dataOrdini?.importoTotOrdiniNettoOriginaleStr}
                                                            </span>
                                                        </div>
                                                        <div className='w-full flex justify-between'>
                                                            <span>
                                                                Totale Spedizioni:
                                                            </span>
                                                            <span className='text-end font-bold'>
                                                                € {dataOrdini?.importoConsegnaStr}
                                                            </span>
                                                        </div>
                                                        <div className='w-full flex justify-between'>
                                                            <span>
                                                                IVA (22%):
                                                            </span>
                                                            <span className='text-end font-bold'>
                                                                € {dataOrdini?.importoTotIvaStr}
                                                            </span>
                                                        </div>
                                                        <div className='w-full flex justify-between bg-[#d6e03d]'>
                                                            <span>
                                                                TOTALE:
                                                            </span>
                                                            <span className='text-end font-bold pl-[5px] border-l border-l-[white]'>
                                                                € {dataOrdini?.importoTotStr}
                                                            </span>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div className='col col-12 mt-[1.2em]'>
                                                    <div className='row'>
                                                        <div className='col col-12'>
                                                            <b>ORDINE NELL' CONSEGNA</b>
                                                        </div>
                                                        <div className='col col-12'>
                                                            <p>
                                                                Qui trovi l'elenco dei lavori che sono contenuti in questo Consegna.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='col col-12'>
                                                    <AcordionLavori
                                                        listLavori={dataOrdini ? dataOrdini.listLavori : [] }
                                                        handleRedirectToDetaglioLavoro={handleRedirectToDetaglioLavoro}
                                                        handleNewTagListinoTemplate={handleNewTagListinoTemplate}
                                                        handleDeleteLavoro={handleDeleteLavoro}
                                                        width={710}
                                                    />
                                                </div>
                                                <div className="col col-12 mt-[10px] mb-[10px] px-0 pl-[15px]">
                                                    <div className="flex border-[#d6e03d] border-[1px] bg-[#f58220] " />
                                                </div>
                                                <div className='col col-12'>
                                                    <div className='row'>
                                                        <div className='col col-12 px-0 pr-[3px]'>
                                                            <div className="flex mx-0 items-center justify-end">

                                                                {dataOrdini?.idStatoConsegna == 10 ?
                                                                    // <Link to={`/dettaglioOrdine/${item.idConsegna}`}>
                                                                    <button className="ml-2  p-[4px] flex rounded px-[4px] bg-[#e70031] hover:bg-[#ff5829]" onClick={() => handleRedirectToDetaglioOrdini(item.idConsegna)} >
                                                                        <img src="https://tipografiaformer.it/img/icoPrezzo16.png" />
                                                                        <b>EFFETTUA IL PAGAMENTO</b>
                                                                    </button>
                                                                    // </Link>

                                                                    : dataOrdini?.tracciabile ?
                                                                        <button className="ml-2 p-1 flex rounded bg-[#ffd30c] hover:bg-[#ffe055]">
                                                                            <img src="https://tipografiaformer.it/img/icoCorriere20.png" width="16" />
                                                                            <b>TRACCIA IL MIO PACCO</b>
                                                                        </button>
                                                                        : null
                                                                }
                                                                {/* <Link to={`/dettaglioOrdine/${item.idConsegna}`}> */}
                                                                <button
                                                                    className="ml-2 p-1 flex rounded bg-[#ffd30c] hover:bg-[#ffe055]"
                                                                    onClick={() => handleRedirectToDetaglioOrdini(item.idConsegna)}
                                                                >
                                                                    <img src="https://tipografiaformer.it/img/icoFreccia16.png" />
                                                                    Vai al Dettaglio Consegna
                                                                </button>
                                                                {/* </Link> */}

                                                                {dataOrdini?.modificabile &&
                                                                    <button
                                                                        className="ml-2 p-1 flex rounded bg-[#ffd30c] hover:bg-[#ffe055]"
                                                                        onClick={() => handleDeleteOrdine(item.idConsegna)}
                                                                    >
                                                                        <img src="https://tipografiaformer.it/img/icoCestino16.png" />
                                                                        Elimina Consegna
                                                                    </button>
                                                                }
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br />
                                    </AccordionDetails>
                                </Accordion>
                            )
                        })
                    }
                    <p className="w-full flex my-[5px] text-[11px]">
                        <span>
                            Vai alla pagina
                        </span>
                    </p>
                    <div className="w-full flex overflow-y-hidden">
                        {pageOrdini.map((item, index) => (
                            <a key={item} className="text-[12px] hover:underline cursor-pointer py-[5px] px-[10px] bg-[#2b2b2b] text-white border-[1px] border-[#aaa] rounded-[3px]" onClick={() => { handleGetOrdini(item) }}>{item}</a>
                        ))
                        }
                    </div>
                </div>
            </div>

        </>
    )
}

export default AcordionOrdini