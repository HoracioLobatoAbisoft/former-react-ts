import React from 'react'

const hooks = () => {
    return {}
}

export default hooks