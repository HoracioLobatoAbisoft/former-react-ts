export interface dataIndirizzo {
    idIndirizzo: number,
    predefinito: boolean,
    nome: string,
    riassunto: string,
    destinatario: string,
    indirisso: string
    localitaStr: string,
    nazioneStr: string,
    telefono: number

}[]