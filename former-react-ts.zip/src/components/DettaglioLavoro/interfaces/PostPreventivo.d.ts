export interface ResponsePostPreventivo {
    data: number;
    message: string;
    status: number;
}
