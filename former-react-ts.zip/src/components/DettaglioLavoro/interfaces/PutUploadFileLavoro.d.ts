export interface ResponsePutUploadFileLavoto {
    message: string,
    data: boolean,
    status: number,
}