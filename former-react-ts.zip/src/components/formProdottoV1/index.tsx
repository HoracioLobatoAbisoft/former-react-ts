import LoadingBackdrop from "../loadingBackdrop"
import { ConfiguraProdotto } from "./ConfiguraProdotto"

export const FormProdottoModificated = () => {
  return (
    <div className="flex justify-center">
      <ConfiguraProdotto />
    </div>
  )
}
