export interface IshowOrientamiento {
    data: boolean;
    message: string;
    status: number;
}
