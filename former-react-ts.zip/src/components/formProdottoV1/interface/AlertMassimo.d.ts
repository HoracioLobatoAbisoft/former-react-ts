export interface DataAlertMassimo {
    data: DataAlertMinimo;
    message: string;
    status: number;
}
export interface DataAlertMinimo {
    lblErroreMisureText: string;
    showErroreMisure: boolean;
}
