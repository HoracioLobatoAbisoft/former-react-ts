export interface ResposeGetHelperDataProdotto {
    data: Data;
    message: string;
    status: number;
}

export interface DataGetHelperDataProdotto {
    url: string;
    idListinoBase: number;
    nome:string;
    imgRif:string;
    idFormato:number;
}
