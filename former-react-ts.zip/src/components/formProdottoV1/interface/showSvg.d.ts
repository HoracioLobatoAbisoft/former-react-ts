export interface showSvgReponse {
    data: boolean;
    message: string;
    status: number;
}
