export interface IShowOpzioni {
    data: number;
    message: string;
    status: number;
}
