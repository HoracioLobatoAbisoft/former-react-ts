export interface ResponseGetInputValue {
    data: number;
    message: string;
    status: number;
}
