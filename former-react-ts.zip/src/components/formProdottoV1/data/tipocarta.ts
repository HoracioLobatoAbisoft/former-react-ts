export const TipoDiCartaData = [
  {
    title: "",
  },
  {
    title: "",
  },
  {
    title: "",
  },
];
