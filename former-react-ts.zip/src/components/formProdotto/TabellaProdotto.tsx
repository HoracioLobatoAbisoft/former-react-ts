
export const TabellaProdotto = () => {
  return (
    <div>TabellaProdotto</div>
  )
}
