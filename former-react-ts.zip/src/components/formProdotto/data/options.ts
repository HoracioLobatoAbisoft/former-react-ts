export const optionsData = [
  {
    title: "Creazione Fustella",
    id: 10,
  },
  {
    title: "Fustellatura Standard",
    id: 20,
  },
  {
    title: "Incollaggio Astucci",
    id: 30,
  },
];
