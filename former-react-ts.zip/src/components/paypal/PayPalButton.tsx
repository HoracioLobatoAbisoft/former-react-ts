
import './stylesPaypal.css'
type PalPalButtonProps = {
    description: string;
    amount: string;
}

const PayPalButton = ({ amount, description }: PalPalButtonProps) => {
    return (
        <></>
    )
}

export default PayPalButton