import React from 'react'

const DiscountComponent = () => {
  return (
    <div>
      
    </div>
  )
}

export default DiscountComponent