import React from 'react'

const Prueba = () => {
    return (
        <div>Prueba</div>
    )
}

export default Prueba