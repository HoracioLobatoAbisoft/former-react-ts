

export type OrdineTable = {
  corriereStr: string;
  idConsegnaView: string;
  giornoStr: string;
  dataOrdineClasse: string;
  signatureCatchPhrase: string;
  statoStr: string;
  count: string;
  importoTotOrdiniNettoOriginaleStr: string;
  coloreStatoHtml: string;
  indirizzoStr: string;
  pesoKG: number;
  colliStr: string;
  pagamentoStr: string;
  importoConsegnaStr: string;
  importoTotIvaStr: string;
  importoTotStr: string;
  inseritoStr: string;
  iconaCorriereAlt: string;
  idConsegna: number;
};




