import { createContext } from "react";

const UserContext = createContext({
  id: "",
  token: ""
 
})
export default UserContext;


